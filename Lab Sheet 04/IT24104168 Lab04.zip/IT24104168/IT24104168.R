# Set working directory
setwd("C:\\Users\\it24104168\\Desktop\\IT24104168")
getwd()
branch_data <- read.table("C:\\Users\\it24104168\\Desktop\\IT24104168\\Exercise.txt",
                          header = TRUE, sep = ",")

#step2,3 Boxplot for Sales
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", 
        col = "green", ylab = "Sales")

# Step 4: Five Number Summary & IQR for Advertising
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

branch_data <- data.frame(
  Branch = 1:30,
  Sales_X1 = c(3.4,4.1,2.8,5,3.7,4.5,3,4.9,3.2,2.5,3.9,4.2,2.7,3.6,4.8,3.3,4,5.1,3.8,2.9,4.4,3.1,4.6,3.5,4.3,3,4.7,2.6,3.9,4.2),
  Advertising_X2 = c(120,150,90,200,110,175,95,185,105,80,130,140,100,125,190,115,135,210,145,85,160,100,170,120,155,90,180,95,140,150),
  Years_X3 = c(4,7,3,10,5,6,2,9,4,1,5,7,3,4,8,5,6,12,6,2,9,3,10,5,8,2,11,1,6,7)
)


# Step 5: Outlier Detection Function
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers
find_outliers(branch_data$Years_X3)
find_outliers(branch_data$Sales_X1)
find_outliers(branch_data$Advertising_X2)

